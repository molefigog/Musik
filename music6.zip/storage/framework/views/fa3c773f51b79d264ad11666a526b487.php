<?php if (isset($component)) { $__componentOriginal166a02a7c5ef5a9331faf66fa665c256 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal166a02a7c5ef5a9331faf66fa665c256 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament-panels::components.page.index','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament-panels::page'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>


    <div class="min-h-screen relative overflow-hidden">

        
        <div class="absolute inset-0 bg-gradient-to-br from-black via-gray-900 to-black"></div>

        <div class="absolute -top-40 -left-40 w-[500px] h-[500px] bg-purple-600/30 blur-[120px] rounded-full"></div>
        <div class="absolute bottom-0 right-0 w-[500px] h-[500px] bg-blue-500/20 blur-[140px] rounded-full"></div>

        <div class="relative max-w-6xl mx-auto px-6 py-10 space-y-10 text-white">

            
            <div class="flex items-center justify-between">

                <div class="flex items-center gap-4">

                    <img src="<?php echo e($music->release?->art_cover ? Storage::url($music->release->art_cover) : 'https://via.placeholder.com/80'); ?>"
                        class="w-16 h-16 rounded-2xl object-cover shadow-lg border border-white/10" />

                    <div>
                        <h1 class="text-2xl font-bold tracking-tight">
                            <?php echo e($music->title); ?>

                        </h1>

                        <p class="text-sm text-white/60">
                            <?php echo e($music->release?->title ?? 'No Release'); ?>

                        </p>
                    </div>

                </div>

                <div class="text-xs text-white/50">
                    <?php echo e($music->created_at?->diffForHumans()); ?>

                </div>

            </div>

            
            <div class="backdrop-blur-xl bg-white/5 border border-white/10 rounded-3xl shadow-2xl overflow-hidden">

                <div class="p-8">

                    <audio id="audio" src="<?php echo e(Storage::url($music->file_src)); ?>"></audio>

                    
                    <div wire:ignore>
                        <div id="waveform" class="h-44 rounded-2xl bg-white/5 border border-white/10"></div>
                    </div>

                </div>

                
                <div class="flex items-center justify-between px-8 py-6 border-t border-white/10 bg-white/5">

                    <p class="text-xs text-white/50">
                        Click Save to generate and save the waveform image. This may take a few seconds.
                    </p>

                    <form id="waveformForm" method="POST" action="<?php echo e(route('waveform.save', $music)); ?>"
                        class="flex items-center gap-4">

                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="waveform" id="waveformInput">
                        <input type="checkbox" name="is_published" id="publishCheckbox"
                            class="accent-indigo-600 h-5 w-5">

                        <button id="saveBtn" type="submit"
                            class="px-6 py-2 rounded-xl bg-black text-white font-semibold hover:bg-gray-200 transition shadow-lg">
                            Save & Return
                        </button>

                    </form>

                </div>

            </div>

            
            <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">

                
                <div class="backdrop-blur-xl bg-white/5 border border-white/10 rounded-3xl p-5">
                    <p class="text-xs text-white/50 mb-4">Release</p>
                    <div class="flex items-center gap-4">
                        <img src="<?php echo e($music->release?->art_cover ? Storage::url($music->release->art_cover) : 'https://via.placeholder.com/80'); ?>"
                            class="w-14 h-14 rounded-xl object-cover border border-white/10" />
                        <div>
                            <div class="font-semibold">
                                <?php echo e($music->release?->title ?? 'No Release'); ?>

                            </div>

                            <div class="text-xs text-white/40">
                                Music Collection
                            </div>
                        </div>
                    </div>
                </div>

                
                <div class="lg:col-span-2 backdrop-blur-xl bg-white/5 border border-white/10 rounded-3xl p-6">
                    <div class="grid grid-cols-2 lg:grid-cols-3 gap-6 text-sm">
                        <div>
                            <p class="text-white/40 text-xs">Duration</p>
                            <p class="font-semibold"><?php echo e($music->duration ?? 'Unknown'); ?></p>
                        </div>

                        <div>
                            <p class="text-white/40 text-xs">Size</p>
                            <p class="font-semibold"><?php echo e($music->size); ?> MB</p>
                        </div>

                        <div>
                            <p class="text-white/40 text-xs">File</p>
                            <p class="text-xs break-all text-white/60">
                                <?php echo e($music->file_name); ?>

                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <?php $__env->startPush('scripts'); ?>
        <script src="<?php echo e(asset('js/wavesurfer.min.js')); ?>"></script>

        <script>
            document.addEventListener('DOMContentLoaded', () => {

                const audio = document.getElementById('audio');
                const waveformEl = document.getElementById('waveform');
                const form = document.getElementById('waveformForm');
                const input = document.getElementById('waveformInput');
                const btn = document.getElementById('saveBtn');
                const publishCheckbox = document.getElementById('publishCheckbox');

                const wavesurfer = WaveSurfer.create({
                    container: waveformEl,
                    waveColor: '#4F4A85',
                    progressColor: '#bbbbbb',
                    height: 150,
                    backend: 'WebAudio',
                });

                wavesurfer.load(audio.src);

                function canvasToBlob(canvas) {
                    return new Promise(resolve => {
                        canvas.toBlob(blob => resolve(blob), 'image/png');
                    });
                }

                form.addEventListener('submit', async (e) => {
                    e.preventDefault();

                    btn.disabled = true;
                    btn.innerText = 'Generating...';

                    try {
                        await new Promise(r => requestAnimationFrame(r));
                        await new Promise(r => requestAnimationFrame(r));

                        const canvas = document.querySelector('#waveform canvas');
                        if (!canvas) throw new Error('Canvas not ready');
                        const blob = await canvasToBlob(canvas);
                        const formData = new FormData(form);
                        formData.append('waveform_file', blob, 'waveform.png');

                        const response = await fetch(form.action, {
                            method: 'POST',
                            body: formData,
                            headers: {
                                'X-CSRF-TOKEN': document.querySelector('input[name="_token"]').value
                            }
                        });

                        if (!response.ok) throw new Error('Upload failed');
                        window.location.href = response.url;

                    } catch (err) {
                        console.error(err);
                        alert(err.message);

                        btn.disabled = false;
                        btn.innerText = 'Save & Return';
                    }
                });

            });
        </script>
    <?php $__env->stopPush(); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal166a02a7c5ef5a9331faf66fa665c256)): ?>
<?php $attributes = $__attributesOriginal166a02a7c5ef5a9331faf66fa665c256; ?>
<?php unset($__attributesOriginal166a02a7c5ef5a9331faf66fa665c256); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal166a02a7c5ef5a9331faf66fa665c256)): ?>
<?php $component = $__componentOriginal166a02a7c5ef5a9331faf66fa665c256; ?>
<?php unset($__componentOriginal166a02a7c5ef5a9331faf66fa665c256); ?>
<?php endif; ?>
<?php /**PATH C:\important\music3\resources\views/filament/pages/wave-surfer.blade.php ENDPATH**/ ?>