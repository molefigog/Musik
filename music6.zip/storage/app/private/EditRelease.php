<?php

namespace App\Filament\Resources\Releases\Pages;

use App\Filament\Resources\Releases\ReleaseResource;
use Filament\Actions\DeleteAction;
use Filament\Forms\Components\TextInput;
use Filament\Resources\Pages\EditRecord;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\ValidationException;
use Filament\Notifications\Notification;
use App\Models\Music;
use App\Models\Genre;
use Filament\Forms\Components\FileUpload;
use Filament\Forms\Components\Select;
use Filament\Actions\Action;
use Filament\Forms\Components\Repeater;
use Filament\Forms\Components\Repeater\TableColumn;

class EditRelease extends EditRecord
{
    protected static string $resource = ReleaseResource::class;

    protected function getHeaderActions(): array
    {
        return [
            DeleteAction::make()
                ->form([
                    TextInput::make('password')
                        ->label('Confirm Password')
                        ->password()
                        ->required(),
                ])

                ->before(function (array $data) {
                    if (! Hash::check($data['password'], Auth::user()->password)) {

                        Notification::make()
                            ->title('Incorrect Password')
                            ->body('The password you entered is incorrect. Deletion was cancelled.')
                            ->danger()
                            ->send();

                        throw ValidationException::withMessages([
                            'password' => 'Incorrect password.',
                        ]);
                    }
                })

                ->successNotificationTitle('Release deleted successfully'),

            Action::make('addTracks')
                ->label('Add Tracks')
                ->icon('heroicon-o-plus')
                ->modalHeading('Add Tracks')
                ->modalWidth('7xl')

                ->form([

                    Repeater::make('tracks')
                        ->reorderable()
                        ->table([
                            TableColumn::make('Name'),
                            TableColumn::make('Amount'),
                            TableColumn::make('Genre'),
                            TableColumn::make('File Source'),
                        ])


                        ->schema([
                            TextInput::make('title')->required(),
                            TextInput::make('price')->numeric()->required(),
                            Select::make('genre_id')
                                ->options(Genre::pluck('title', 'id'))
                                ->searchable()
                                ->required(),
                            FileUpload::make('file_src')
                                ->disk('public')
                                ->directory('music')
                                ->acceptedFileTypes(['audio/*'])
                                ->storeFileNamesIn('file_name')
                                ->moveFiles(),


                        ])
                        ->columns(2)
                        ->defaultItems(1)
                        ->reorderable(),

                ])

                ->action(function (array $data, $livewire) {

                    foreach ($data['tracks'] as $track) {
                        Music::create([
                            'release_id' => $this->record->id,
                            'title' => $track['title'],
                            'price' => $track['price'],
                            'genre_id' => $track['genre_id'],
                            'file_src' => $track['file_src'],
                        ]);
                    }

                    $livewire->dispatch('generate-waveforms', $data);

                    Notification::make()
                        ->title('Tracks added successfully')
                        ->success()
                        ->send();
                })
        ];
    }
}
