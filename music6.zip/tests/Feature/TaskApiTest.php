<?php

namespace Tests\Feature;

use App\Models\User;
use App\Models\Payment;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class TaskApiTest extends TestCase
{
    use RefreshDatabase;

    public function test_authenticated_user_can_create_a_task(): void
    {
        $user = User::factory()->create();
        $payment = Payment::create([
            'user_id' => $user->id,
            'amount' => 1,
            'status' => 'completed',
            'txn_id' => 'PAY-123',
            'msisdn' => '26650000000',
            'conversation_id' => 'PAY-123',
            'type' => 'paypal',
            'description' => 'New beat task',
        ]);

        $response = $this->actingAs($user, 'sanctum')
            ->postJson('/api/tasks', [
                'service_type' => 'beat',
                'title' => 'New beat task',
                'details' => 'Please craft a fresh beat',
                'amount' => 1,
                'payment_txn_id' => $payment->txn_id,
                'payment_type' => $payment->type,
            ]);

        $response->assertCreated();
        $response->assertJsonPath('data.title', 'New beat task');
        $response->assertJsonPath('data.service_type', 'beat');

        $this->assertDatabaseHas('tasks', [
            'user_id' => $user->id,
            'service_type' => 'beat',
            'title' => 'New beat task',
            'payment_id' => $payment->id,
            'status' => false,
        ]);
    }

    public function test_failed_payment_cannot_create_a_task(): void
    {
        $user = User::factory()->create();
        Payment::create([
            'user_id' => $user->id,
            'amount' => 1,
            'status' => 'failed',
            'txn_id' => 'PAY-FAILED',
            'msisdn' => '26650000000',
            'conversation_id' => 'PAY-FAILED',
            'type' => 'paypal',
            'description' => 'Failed task',
        ]);

        $this->actingAs($user, 'sanctum')
            ->postJson('/api/tasks', [
                'service_type' => 'beat',
                'title' => 'Failed task',
                'amount' => 1,
                'payment_txn_id' => 'PAY-FAILED',
                'payment_type' => 'paypal',
            ])
            ->assertUnprocessable();

        $this->assertDatabaseMissing('tasks', ['title' => 'Failed task']);
    }
}
