<!DOCTYPE html>
<html>
<head>
    <title>Payment Result</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="refresh" content="0;url=http://localhost:9000/#/payment-result?status={{$status}}">
    <style>
        body {
            font-family: Arial;
            background: #f4f7fb;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .card {
            background: white;
            padding: 40px;
            border-radius: 16px;
            text-align: center;
            width: 90%;
            max-width: 420px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        }
        .success { color: #21ba45; }
        .failed { color: #c10015; }
        .btn {
            margin-top: 20px;
            display: inline-block;
            padding: 12px 20px;
            background: #1976d2;
            color: white;
            text-decoration: none;
            border-radius: 8px;
        }
    </style>
</head>
<body>

<div class="card">

    <div style="font-size:60px;">
        {{ $status === 'completed' ? '✅' : '❌' }}
    </div>
    <h2 class="{{ $status === 'completed' ? 'success' : 'failed' }}">
        {{ $status === 'completed' ? 'Payment Successful' : 'Payment Failed' }}
    </h2>
    <p>Transaction ID: <b>{{ $txnId }}</b></p>
    <a class="btn" href="{{ $redirect }}">
        Return Home
    </a>
{{--
   <a href="http://localhost:9000/#/payment-result?status={{$status}}">click here to return to the app</a>. --}}
</p>

</div>


</body>
</html>
