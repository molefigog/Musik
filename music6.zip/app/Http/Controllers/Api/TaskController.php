<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Resources\TaskResource;
use App\Models\Payment;
use App\Models\Task;
use App\Services\TaskProvisioningService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class TaskController extends Controller
{
    // GET /api/tasks — only the authenticated user's own tasks
    public function index(Request $request)
    {
        $tasks = $request->user()
            ->tasks()
            ->latest()
            ->get();

        return TaskResource::collection($tasks);
    }

    // POST /api/tasks — create a task for the authenticated user
    public function store(Request $request, TaskProvisioningService $provisioning)
    {
        $validator = Validator::make($request->all(), [
            'service_type' => ['required', 'in:beat,recording,artwork'],
            'title' => ['required', 'string', 'max:255'],
            'details' => ['nullable', 'string'],
            'amount' => ['required', 'numeric', 'min:0.01'],
            'payment_txn_id' => ['required', 'string'],
            'payment_type' => ['required', 'in:cpay,mpesa,paypal,card'],
        ]);

        if ($validator->fails()) {
            return response()->json([
                'message' => 'Validation failed',
                'errors' => $validator->errors(),
            ], 422);
        }

        $payment = Payment::query()
            ->where('user_id', $request->user()->id)
            ->where('txn_id', $request->payment_txn_id)
            ->where('type', $request->payment_type)
            ->where('status', 'completed')
            ->first();

        if (! $payment) {
            return response()->json([
                'message' => 'A completed payment is required before creating a task.',
            ], 422);
        }

        if ($payment->task) {
            $task = $payment->task;
        } else {
            $payment->update([
                'service_type' => $request->service_type,
                'title' => $request->title,
                'description' => $request->details,
            ]);
            $task = $provisioning->createFromPayment($payment->fresh());
        }

        if (! $task) {
            return response()->json(['message' => 'Unable to create task from payment.'], 422);
        }

        return (new TaskResource($task))->response()->setStatusCode(201);
    }

    // GET /api/tasks/{task} — single task, scoped to owner
    public function show(Request $request, Task $task)
    {
        abort_if($task->user_id !== $request->user()->id, 403);

        return new TaskResource($task);
    }
}
